Clyde Chen, A00914442, COMP1B, October-03-2014

This assignment is 100% complete.


------------------------
Question one (Change) status:

complete
checkstyle: line 29 says executable count is 36 while the max is 30
	is possibly a checkstyle error as this method declaration
	must be on the same line and should include all the statements
	that makes this line longer than 30.

------------------------
Question two (SecondsConvert) status:

complete

------------------------
Question three (Arithemtic) status:

complete

------------------------
Question four (Cube) status:

complete
------------------------
Question five (Pie Chart) status:

complete
checkstyle: line 78 says executable count is 32 while the max is 30
	is possibly a checkstyle error as this method declaration
	must be on the same line and should include all the statements
	that made this line longer than 30.
